package com.jmu.kirito.smartpicture.common;


import com.jmu.kirito.smartpicture.exception.ErrCode;
import lombok.Data;

import java.io.Serializable;

/**
 * 全局响应封装类
 *
 * @param <T>
 */
@Data
public class BaseResponse<T> implements Serializable {

    private int code;

    private T data;

    private String message;

    public BaseResponse(int code, T data, String message) {
        this.code = code;
        this.data = data;
        this.message = message;
    }

    public BaseResponse(int code, T data) {
        this(code, data, "");
    }

    public BaseResponse(ErrCode errorCode) {
        this(errorCode.getCode(), null, errorCode.getMessage());
    }
}