package com.jmu.kirito.smartpicture;

import cn.hutool.core.lang.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartPictureBackendApplicationTests {

    @Test
    void contextLoads() {
        System.out.println(UUID.fastUUID().toString().replace("-", ""));
    }

}
